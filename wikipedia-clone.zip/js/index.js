$("#btn").click(function(){
var searchTerm= $("#topic").val();
var url="//en.wikipedia.org/w/api.php?action=opensearch&search="+searchTerm+"&format=json&callback=?";

$.ajax({
  type:"GET",
  url:url,
  async:false,
  dataType:"json",
  success: function(data){
    $(".result").html("");
    
    for(var i=0; i<data[1].length;i++){
      $(".result").addClass("span-size");
      $(".result").append("<a href="+data[3][i]+">"+data[1][i]+"</a><p>"+data[2][i]+"</p>");
    }
    
  },
  error: function(errorMessage){
    alert("Error");
  }
  
});
});